package domain;

public class Comentarios {

    //Falta crear el ranking
    //falta chequear que el cliente pueda solicitar soporte de un servicio
}
