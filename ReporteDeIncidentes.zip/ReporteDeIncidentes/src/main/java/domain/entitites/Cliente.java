package domain.entitites;

public class Cliente {
    private String cuit;
    private String email;
    private String razonSocial;
    private String numeroCompleto;
}
