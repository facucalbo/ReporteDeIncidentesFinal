package domain.entitites.servicios;

import domain.entitites.problemas.TipoProblema;

import java.util.ArrayList;
import java.util.List;

public class Servicio {
    private String nombreServicio;
    private List<TipoProblema> tiposDeProblema;

    public Servicio(){
        this.tiposDeProblema = new ArrayList<>();
    }
}
