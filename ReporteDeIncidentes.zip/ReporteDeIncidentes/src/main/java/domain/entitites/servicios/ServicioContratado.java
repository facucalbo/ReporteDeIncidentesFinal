package domain.entitites.servicios;

import domain.entitites.Cliente;

import java.time.LocalDate;

public class ServicioContratado {
    private Cliente cliente;
    private Servicio servicio;
    private LocalDate fechaAlta;
}
