package domain.entitites.incidente;

public class PosibleEstadoIncidente {
    public static String nombreEstado;

}
