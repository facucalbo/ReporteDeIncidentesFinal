package domain.entitites;

import domain.entitites.notificacion.Notificacion;
import domain.entitites.problemas.Problema;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class Tecnico {
    private String nombreTecnico;
    private String apellidoTecnico;
    private String emailTecnico;
    private String numeroCompleto;
    private boolean disponible;
    private List<Especialidad> especialidades;

    public Tecnico(){
        this.especialidades = new ArrayList<>();
    }

    public boolean estasDisponible(){
        return this.disponible;
    }

    public boolean resuelveProblema(Problema problema){

        return especialidades
                .stream()
                .anyMatch(e -> problema.getEspecialidadesQueResuelven().contains(e));
    }

    public void recibirNotificacion(Notificacion notificacion){
        //todo
    }

    public void agregarEspecialidad(Especialidad especialidad){
        this.especialidades.add(especialidad);
    }

}