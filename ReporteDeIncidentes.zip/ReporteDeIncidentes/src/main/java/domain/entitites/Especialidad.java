package domain.entitites;

public class Especialidad {
    private String nombreEspecialidad;
}
