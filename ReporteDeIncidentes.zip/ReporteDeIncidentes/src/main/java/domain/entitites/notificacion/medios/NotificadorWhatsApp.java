package domain.entitites.notificacion.medios;

import domain.entitites.notificacion.Notificacion;

public class NotificadorWhatsApp implements MedioDeNotificacion{

    @Override
    public void enviar(Notificacion notificacion) {
        //TODO
    }
}
