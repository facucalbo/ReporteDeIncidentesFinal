package domain.entitites.problemas;

import java.util.ArrayList;
import java.util.List;

public class TipoProblema {
    private String nombreTipoProblema;
    private List<Problema> problemas;

    public TipoProblema(){
        this.problemas = new ArrayList<>();
    }
}
